/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/Xilinx Work/IIITN_Water_pump/AND_3.vhd";



static void work_a_0414197264_3212880686_p_0(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(16, ng0);

LAB3:    t3 = (t0 + 592U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    if (t5 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    t3 = (t0 + 1768);
    t10 = (t3 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast_port(t3);

LAB2:    t14 = (t0 + 1724);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    t3 = (t0 + 776U);
    t8 = *((char **)t3);
    t9 = *((unsigned char *)t8);
    t1 = t9;
    goto LAB7;

LAB8:    t3 = (t0 + 684U);
    t6 = *((char **)t3);
    t7 = *((unsigned char *)t6);
    t2 = t7;
    goto LAB10;

}


extern void work_a_0414197264_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0414197264_3212880686_p_0};
	xsi_register_didat("work_a_0414197264_3212880686", "isim/STR_IIITN_isim_beh.exe.sim/work/a_0414197264_3212880686.didat");
	xsi_register_executes(pe);
}
